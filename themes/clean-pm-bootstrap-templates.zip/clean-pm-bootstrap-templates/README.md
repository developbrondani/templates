# Clean PM Bootstrap Templates
Bootstrap Templates for Administrator Site
base on AngularJS

- Responsive AngularJS Base Templates
- Include Awesome AngularJS plugins. such as Chart.js, Datatable, UI-Bootstrap. UI-Select, UI-Router, ngInfiniteScroll, ngToast etc.
- Include most Bootstrap3 elements. And this templates include examples page such as Login, Register, Datatable etc

Screenshot
![SS](http://templates.tui2tone.me/assets/img/cleanpm/dashboard.png)

[Live Demo](http://www.tui2tone.me/clean-pm-bootstrap-templates/)
