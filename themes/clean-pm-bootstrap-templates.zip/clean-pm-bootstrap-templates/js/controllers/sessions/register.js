angular.module("app").controller('SessionRegisterCtrl', ['$scope','$modal','ngToast', function($scope,$modal,ngToast) {
    
}]);
