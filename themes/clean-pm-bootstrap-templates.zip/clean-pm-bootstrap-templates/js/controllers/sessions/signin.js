angular.module("app").controller('SessionSigninCtrl', ['$scope', '$modal', '$timeout','$state', function($scope, $modal, $timeout,$state) {
    $scope.login = {
        mode: "",
        message: "Please Login.",
        errors: {
        	username: false,
        	password: false
        },
        user: {
            username: "",
            password: ""
        },
        login: function(user) {
        	$scope.login.errors = {}
            $scope.login.mode = "loading";
            $scope.login.message = "Loading. Please Wait.";
            $timeout(function() {
            	if(user.username == "" && user.password == "") {
            		$scope.login.message = "Please fill username and password";
            		$scope.login.errors.username = true;
            		$scope.login.errors.password = true;
            		$scope.login.mode = "errors"
            	} else if (user.username == "") {
            		$scope.login.message = "Please fill username";
            		$scope.login.errors.username = true;
            		$scope.login.mode = "errors"
            	} else if (user.password == "") {
            		$scope.login.message = "Please fill password";
            		$scope.login.errors.password = true;
            		$scope.login.mode = "errors"
            	} else {
            		$scope.login.mode = "success"
            		$scope.login.message = "Login Success. Please Wait.";
            		$timeout(function() {
            			$state.go('main.dashboard')
            		}, 1000);
            	}
                
            }, 1000);
        },
        change: function() {
        	$scope.login.mode = "";
            $scope.login.message = "Please Login.";
        	$scope.login.errors = {}
        }
    }
}]);
