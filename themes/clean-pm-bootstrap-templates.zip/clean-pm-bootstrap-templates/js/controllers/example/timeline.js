angular.module("app").controller('ExampleTimeLineCtrl', ['$scope','DTOptionsBuilder','DTColumnBuilder', function($scope,DTOptionsBuilder,DTColumnBuilder){
	
}]);